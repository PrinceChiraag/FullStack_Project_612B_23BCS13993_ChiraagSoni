package com.grievanceportal.grievance_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrievanceBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
